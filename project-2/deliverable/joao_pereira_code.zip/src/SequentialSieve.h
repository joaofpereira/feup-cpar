#ifndef SIEVESEQUENTIAL_H
#define SIEVESEQUENTIAL_H

#include <iostream>
#include <time.h>
#include <cmath>

using namespace std;

double sequencialSieve(bool* list, unsigned long size);

#endif
