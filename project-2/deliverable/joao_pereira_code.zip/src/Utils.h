#ifndef UTILS_H
#define UTILS_H

#include <iostream>
#include <fstream>
#include <stdlib.h>

using namespace std;

void printPrimesList(const bool* list, unsigned long size);
bool* newList(unsigned long n);
int askForWorkingThreads(int maxThreads);

#endif
